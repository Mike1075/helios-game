# Helios 项目凭证信息

⚠️ **重要提醒：此文件包含敏感信息，请勿提交到Git仓库！**

## GitHub 信息
- **用户名**: Lawsquare
- **仓库名**: helios-game
- **仓库URL**: https://github.com/Lawsquare/helios-game
- **Personal Access Token**: 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


## n8n 信息
- **部署类型**: 云部署
- **基础URL**: https://n8n.aifunbox.com
- **Webhook URL**: https://n8n.aifunbox.com/webhook/58a6c8c7-52ff-4c2f-8809-101f1e16ed9a
- **备用Webhook ID**: afc32e56-6565-4a21-9ae1-1040889911cc
- **工作流名称**: 元宇宙mvp v0.2

## Supabase 信息
- **项目URL**: https://remukeaazmezhksoawrf.supabase.co
- **Service Role Key**: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJlbXVrZWFhem1lemhrc29hd3JmIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1NTIyMjUxMCwiZXhwIjoyMDcwNzk4NTEwfQ.4pVPosybxjMtZjWETAEbKPGTjXjBIpngwcFYaf7Y2Dk
- **Anon Key**: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJlbXVrZWFhem1lemhrc29hd3JmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUyMjI1MTAsImV4cCI6MjA3MDc5ODUxMH0.SbIAm5I_lW0S4YJtCE9I3k3F7nIG-ec-xnC0UuI2a70
- **Edge Function**: database-access
- **Edge Function URL**: https://remukeaazmezhksoawrf.supabase.co/functions/v1/database-access

## Vercel 信息
- **账号**: [待填写]
- **项目名**: helios-game
- **部署URL**: [待填写]

## API Keys
- **Vercel AI SDK**: 94TyvNQ1ziPqGCkLddgiYlo8
- **Vercel AI Gateway**: [从n8n配置中获取]
  - ID: BaNpz2bHZ90INuuN
  - Name: Vercel AI Gateway zfx
- **Cohere API**: [从n8n配置中获取]
  - ID: 9cL3996dtv4T7kL1
  - Name: CohereApi account

## 安全注意事项
1. 定期更换所有token和密钥
2. 不要将此文件提交到Git
3. 使用环境变量存储敏感信息
4. 定期检查GitHub的安全日志

## 更新日志
- 2024-XX-XX: 创建凭证文件
- 2024-XX-XX: GitHub token泄露，需要重新生成

---
最后更新: $(date)
