机密凭据备忘（请勿公开提交）
用途：仅供本地团队成员查阅；请勿公开到任何公共仓库/截图/分享渠道。如已泄露请立刻在 Supabase/Vercel 侧轮换密钥。

环境变量
```env
# Supabase
SUPABASE_URL=https://remukeaazmezhksoawrf.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJlbXVrZWFhem1lemhrc29hd3JmIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1NTIyMjUxMCwiZXhwIjoyMDcwNzk4NTEwfQ.4pVPosybxjMtZjWETAEbKPGTjXjBIpngwcFYaf7Y2Dk
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJlbXVrZWFhem1lemhrc29hd3JmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUyMjI1MTAsImV4cCI6MjA3MDc5ODUxMH0.SbIAm5I_lW0S4YJtCE9I3k3F7nIG-ec-xnC0UuI2a70

# Vercel AI SDK (Vercel AI Inference)
VERCEL_AI_API_KEY=94TyvNQ1ziPqGCkLddgiYlo8
```

Edge Function
- Slug：database-access
- Endpoint URL：https://remukeaazmezhksoawrf.supabase.co/functions/v1/database-access

建议存放位置（仅供参考）
- 本仓库开发环境读取：packages/web/.env.local
- Supabase Edge Functions 环境变量：在 Supabase 项目中配置（Functions Settings）
- 注意：本文件仅为备忘，不建议提交到公共仓库。如需忽略提交，请在 .gitignore 中加入 docs/private/